

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-users me-2 text-primary"></i>User Management</h2>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #1a73e8, #0d47a1)">
            <i class="fas fa-users"></i>
            <h3><?php echo e($users->total()); ?></h3>
            <p>Total Users</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #10b981, #059669)">
            <i class="fas fa-user-shield"></i>
            <h3><?php echo e($users->where('role', 'admin')->count()); ?></h3>
            <p>Admins</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9)">
            <i class="fas fa-user"></i>
            <h3><?php echo e($users->where('role', 'customer')->count()); ?></h3>
            <p>Customers</p>
        </div>
    </div>
</div>


<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.users.index')); ?>">
            <div class="row g-3 align-items-center">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white">
                            <i class="fas fa-search text-primary"></i>
                        </span>
                        <input type="text" name="search" class="form-control" placeholder="Search by name or email..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="role" class="form-select">
                        <option value="">All Roles</option>
                        <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="customer" <?php echo e(request('role') == 'customer' ? 'selected' : ''); ?>>Customer</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Filter
                    </button>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-times me-1"></i>Clear
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Total Orders</th>
                    <th>Joined</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td>
                        <i class="fas fa-user-circle text-primary me-1"></i>
                        <?php echo e($user->name); ?>

                        <?php if($user->id === auth()->id()): ?>
                            <span class="badge bg-primary ms-1">You</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if($user->role == 'admin'): ?>
                            <span class="badge bg-success"><i class="fas fa-user-shield me-1"></i>Admin</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-user me-1"></i>Customer</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge bg-primary"><?php echo e($user->orders_count); ?> orders</span></td>
                    <td><small class="text-muted"><?php echo e($user->created_at->format('M d, Y')); ?></small></td>
                    <td>
                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i>
                        </a>
                        <?php if($user->id !== auth()->id()): ?>
                        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display:inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Delete this user?')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-4 text-muted">
                        <i class="fas fa-users fa-2x mb-2 d-block"></i>No users found!
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<div class="d-flex justify-content-center mt-4">
    <?php echo e($users->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/admin/users/index.blade.php ENDPATH**/ ?>