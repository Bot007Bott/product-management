

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-shopping-cart me-2 text-primary"></i>Product Details</h2>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Back
    </a>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-5 mb-4">
                <div class="card h-100">
                    <div class="product-img" style="height:220px">
                        <i class="fas fa-box-open text-primary" style="font-size:5rem;opacity:0.3"></i>
                    </div>
                    <div class="card-body">
                        <span class="badge-category mb-2 d-inline-block"><?php echo e($product->category->name); ?></span>
                        <h4 class="fw-bold"><?php echo e($product->name); ?></h4>
                        <p class="text-muted"><?php echo e($product->description); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="product-price">$<?php echo e(number_format($product->price, 2)); ?></span>
                            <?php if($product->stock == 0): ?>
                                <span class="badge bg-danger">Out of Stock</span>
                            <?php elseif($product->stock <= 5): ?>
                                <span class="badge bg-warning text-dark">Only <?php echo e($product->stock); ?> left!</span>
                            <?php else: ?>
                                <span class="badge bg-success"><?php echo e($product->stock); ?> in stock</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7 mb-4">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4"><i class="fas fa-clipboard-list me-2 text-primary"></i>Order Details</h5>

                        
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mb-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <div class="mb-3">
                                <label class="form-label">Quantity</label>
                                <input type="number" name="quantity" class="form-control" min="1" max="<?php echo e($product->stock); ?>" value="1" required>
                                <small class="text-muted">Max: <?php echo e($product->stock); ?> items</small>
                            </div>
                            <button type="submit" class="btn btn-outline-primary w-100 mb-2">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </button>
                        </form>

                        
                        <form action="<?php echo e(route('customer.order')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="quantity" value="1">
                            <div class="card bg-light mb-3">
                                <div class="card-body py-3">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted">Price per item</span>
                                        <strong>$<?php echo e(number_format($product->price, 2)); ?></strong>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex justify-content-between">
                                        <span class="fw-bold">Total</span>
                                        <strong class="text-primary" id="total">$<?php echo e(number_format($product->price, 2)); ?></strong>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 py-2">
                                <i class="fas fa-check-circle me-2"></i>Buy Now
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const price = <?php echo e($product->price); ?>;
    document.querySelector('[name="quantity"]').addEventListener('input', function() {
        const total = (this.value * price).toFixed(2);
        document.getElementById('total').textContent = '$' + total;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/customer/show.blade.php ENDPATH**/ ?>