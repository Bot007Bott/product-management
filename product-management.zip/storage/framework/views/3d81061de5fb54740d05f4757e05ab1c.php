

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-edit me-2 text-primary"></i>Edit Category</h2>
    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Back
    </a>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body p-4">
                <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label class="form-label">Category Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($category->name); ?>" required>
                    </div>
                    <div class="d-flex gap-2 mt-2">
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="fas fa-save me-2"></i>Update Category
                        </button>
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-secondary px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>