

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-box me-2 text-primary"></i>My Orders</h2>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Continue Shopping
    </a>
</div>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #f59e0b, #d97706)">
            <i class="fas fa-clock"></i>
            <h3><?php echo e($orders->where('status', 'pending')->count()); ?></h3>
            <p>Pending</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #1a73e8, #0d47a1)">
            <i class="fas fa-spinner"></i>
            <h3><?php echo e($orders->where('status', 'processing')->count()); ?></h3>
            <p>Processing</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #10b981, #059669)">
            <i class="fas fa-check-circle"></i>
            <h3><?php echo e($orders->where('status', 'completed')->count()); ?></h3>
            <p>Completed</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #ef4444, #dc2626)">
            <i class="fas fa-times-circle"></i>
            <h3><?php echo e($orders->where('status', 'cancelled')->count()); ?></h3>
            <p>Cancelled</p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>
                        <div class="fw-bold"><?php echo e($order->product->name); ?></div>
                        <small class="text-muted">$<?php echo e(number_format($order->product->price, 2)); ?> each</small>
                    </td>
                    <td><span class="badge bg-secondary">x<?php echo e($order->quantity); ?></span></td>
                    <td><strong class="text-primary">$<?php echo e(number_format($order->total_price, 2)); ?></strong></td>
                    <td>
                        <?php if($order->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark"><i class="fas fa-clock me-1"></i>Pending</span>
                        <?php elseif($order->status == 'processing'): ?>
                            <span class="badge bg-info"><i class="fas fa-spinner me-1"></i>Processing</span>
                        <?php elseif($order->status == 'completed'): ?>
                            <span class="badge bg-success"><i class="fas fa-check me-1"></i>Completed</span>
                        <?php elseif($order->status == 'cancelled'): ?>
                            <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Cancelled</span>
                        <?php endif; ?>
                    </td>
                    <td><small class="text-muted"><?php echo e($order->created_at->format('M d, Y')); ?></small></td>
                    <td>
                        <?php if($order->status == 'pending'): ?>
                            <form action="<?php echo e(route('customer.order.cancel', $order->id)); ?>" method="POST" style="display:inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Cancel this order?')">
                                    <i class="fas fa-times me-1"></i>Cancel
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted small">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-5 text-muted">
                        <i class="fas fa-box fa-3x mb-3 d-block"></i>
                        <h6>No orders yet!</h6>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-2">Start Shopping</a>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/customer/orders.blade.php ENDPATH**/ ?>