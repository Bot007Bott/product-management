

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-shopping-cart me-2 text-primary"></i>My Cart</h2>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Continue Shopping
    </a>
</div>

<?php if($carts->count() > 0): ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="fw-bold"><?php echo e($cart->product->name); ?></div>
                                <small class="text-muted"><?php echo e($cart->product->category->name); ?></small>
                            </td>
                            <td><strong class="text-primary">$<?php echo e(number_format($cart->product->price, 2)); ?></strong></td>
                            <td style="width:150px">
                                <form action="<?php echo e(route('cart.update', $cart->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="input-group input-group-sm">
                                        <input type="number" name="quantity" class="form-control" value="<?php echo e($cart->quantity); ?>" min="1" max="<?php echo e($cart->product->stock); ?>" onchange="this.form.submit()">
                                    </div>
                                </form>
                            </td>
                            <td><strong>$<?php echo e(number_format($cart->product->price * $cart->quantity, 2)); ?></strong></td>
                            <td>
                                <form action="<?php echo e(route('cart.remove', $cart->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('Remove item?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="fas fa-receipt me-2 text-primary"></i>Order Summary</h5>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small"><?php echo e($cart->product->name); ?> x<?php echo e($cart->quantity); ?></span>
                    <span>$<?php echo e(number_format($cart->product->price * $cart->quantity, 2)); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <div class="d-flex justify-content-between mb-4">
                    <span class="fw-bold">Total</span>
                    <strong class="text-primary fs-5">$<?php echo e(number_format($total, 2)); ?></strong>
                </div>
                <form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary w-100 py-2" onclick="return confirm('Place order for all items?')">
                        <i class="fas fa-check-circle me-2"></i>Checkout (<?php echo e($carts->count()); ?> items)
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="text-center py-5">
    <i class="fas fa-shopping-cart fa-4x text-muted mb-3 d-block"></i>
    <h4 class="text-muted">Your cart is empty!</h4>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-3">
        <i class="fas fa-store me-2"></i>Start Shopping
    </a>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/customer/cart.blade.php ENDPATH**/ ?>