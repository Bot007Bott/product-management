

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2><i class="fas fa-tachometer-alt me-2 text-primary"></i>Dashboard</h2>
    <span class="text-muted">Welcome back, <?php echo e(auth()->user()->name); ?>! 👋</span>
</div>


<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #1a73e8, #0d47a1)">
            <i class="fas fa-box-open"></i>
            <h3><?php echo e($totalProducts); ?></h3>
            <p>Total Products</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9)">
            <i class="fas fa-tags"></i>
            <h3><?php echo e($totalCategories); ?></h3>
            <p>Categories</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #10b981, #059669)">
            <i class="fas fa-dollar-sign"></i>
            <h3>$<?php echo e(number_format($totalRevenue, 2)); ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #f59e0b, #d97706)">
            <i class="fas fa-clock"></i>
            <h3><?php echo e($pendingOrders); ?></h3>
            <p>Pending Orders</p>
        </div>
    </div>
</div>


<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #06b6d4, #0891b2)">
            <i class="fas fa-users"></i>
            <h3><?php echo e($totalCustomers); ?></h3>
            <p>Total Customers</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #ef4444, #dc2626)">
            <i class="fas fa-times-circle"></i>
            <h3><?php echo e($outOfStock); ?></h3>
            <p>Out of Stock</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #ec4899, #db2777)">
            <i class="fas fa-shopping-cart"></i>
            <h3><?php echo e($totalOrders); ?></h3>
            <p>Total Orders</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #14b8a6, #0f766e)">
            <i class="fas fa-exclamation-triangle"></i>
            <h3><?php echo e($lowStockProducts->count()); ?></h3>
            <p>Low Stock Items</p>
        </div>
    </div>
</div>

<div class="row">
    
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-body p-0">
                <div class="p-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-3"><i class="fas fa-shopping-cart me-2 text-primary"></i>Recent Orders</h5>
                    <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->user->name); ?></td>
                            <td><?php echo e($order->product->name); ?></td>
                            <td><strong class="text-primary">$<?php echo e(number_format($order->total_price, 2)); ?></strong></td>
                            <td>
                                <?php if($order->status == 'pending'): ?>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                <?php elseif($order->status == 'processing'): ?>
                                    <span class="badge bg-info">Processing</span>
                                <?php elseif($order->status == 'completed'): ?>
                                    <span class="badge bg-success">Completed</span>
                                <?php elseif($order->status == 'cancelled'): ?>
                                    <span class="badge bg-danger">Cancelled</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">No orders yet!</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="fas fa-exclamation-triangle me-2 text-warning"></i>Low Stock Alert</h5>
                <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex justify-content-between align-items-center mb-3 p-2 rounded" style="background:#fff7ed">
                    <div>
                        <div class="fw-bold small"><?php echo e($product->name); ?></div>
                        <small class="text-muted"><?php echo e($product->category->name); ?></small>
                    </div>
                    <span class="badge bg-warning text-dark"><?php echo e($product->stock); ?> left</span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-3 text-muted">
                    <i class="fas fa-check-circle text-success fa-2x mb-2 d-block"></i>
                    All products well stocked!
                </div>
                <?php endif; ?>

                <?php if($outOfStock > 0): ?>
                <div class="alert alert-danger mt-3 mb-0 py-2">
                    <i class="fas fa-times-circle me-2"></i>
                    <strong><?php echo e($outOfStock); ?></strong> product(s) out of stock!
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Limkokwing degree semester 3\Web Programming 2\Laravel Project\product-management\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>